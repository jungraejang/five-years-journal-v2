module.exports = {
  secret: "only-jrj-knows",
  jwtExpiration: 3600, // 1 hour 3600
  jwtRefreshExpiration: 7200, // 24 hours
};
